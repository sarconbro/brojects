if (!window.__halloWeltLoaded) {
  window.__halloWeltLoaded = true;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "collectUrls") {
      const urls = [...new Set(
        Array.from(document.querySelectorAll("a"))
          .map(link => link.href)
          .filter(href => href.includes("/expose/"))
      )];
      console.log(urls);
      sendResponse({ urls });
    }
  });
}
