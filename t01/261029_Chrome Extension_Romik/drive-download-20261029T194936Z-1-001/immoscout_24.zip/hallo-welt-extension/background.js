const DELAY_MS = 2000; // Pause zwischen zwei Seiten

// Was auf jeder Exposé-Seite passieren soll (läuft im Kontext der Seite)
async function processPage() {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  console.log("Exposé geöffnet:", location.href);

  await wait(3000); // 3 Sekunden vor dem Klick

  const button = document.getElementById("contact-realtor-desk");
  if (button) {
    button.click();
    console.log("Button geklickt");
  } else {
    console.warn("Button 'contact-realtor-desk' nicht gefunden");
  }

  await wait(3000); // 3 Sekunden nach dem Klick

  // Textarea anklicken und Nachricht eintragen
  const textarea = document.getElementById("message");
  if (textarea) {
    textarea.click();
    textarea.focus();

    // Wert so setzen, dass auch Frameworks wie React die Änderung bemerken
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
    setter.call(textarea, "Hi it is just a joke......HHAHAHAAHAH");
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    textarea.dispatchEvent(new Event("change", { bubbles: true }));

    console.log("Nachricht eingetragen");
  } else {
    console.warn("Textarea 'message' nicht gefunden");
  }

  await wait(3000); // kurz stehen lassen, damit man das Ergebnis sieht

  return { url: location.href, title: document.title, clicked: !!button, filled: !!textarea };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "start") {
    chrome.storage.session
      .set({ queue: msg.urls, index: 0, tabId: msg.tabId, running: true, waiting: false, results: [] })
      .then(openNext);
    sendResponse({ ok: true });
  } else if (msg.action === "stop") {
    chrome.storage.session.set({ running: false, waiting: false });
    sendResponse({ ok: true });
  } else if (msg.action === "status") {
    chrome.storage.session.get(["queue", "index", "running"]).then(sendResponse);
    return true; // Antwort kommt asynchron
  }
});

async function openNext() {
  const s = await chrome.storage.session.get(["queue", "index", "tabId", "running", "results"]);
  if (!s.running) return;

  if (s.index >= s.queue.length) {
    await chrome.storage.session.set({ running: false });
    console.log("Fertig. Ergebnisse:", s.results);
    return;
  }

  await chrome.storage.session.set({ waiting: true });
  await chrome.tabs.update(s.tabId, { url: s.queue[s.index] });
}

// Wenn die Seite fertig geladen ist: verarbeiten und zur nächsten URL
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status !== "complete") return;

  const s = await chrome.storage.session.get(["index", "tabId", "running", "waiting", "results"]);
  if (!s.running || !s.waiting || tabId !== s.tabId) return;
  await chrome.storage.session.set({ waiting: false });

  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: processPage
    });
    s.results.push(result);
  } catch (err) {
    console.warn("Fehler auf Seite", s.index, err.message);
  }

  await chrome.storage.session.set({ index: s.index + 1, results: s.results });
  setTimeout(openNext, DELAY_MS);
});

// Durchlauf beenden, wenn der Tab geschlossen wird
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { tabId: activeTab } = await chrome.storage.session.get("tabId");
  if (tabId === activeTab) chrome.storage.session.set({ running: false, waiting: false });
});
