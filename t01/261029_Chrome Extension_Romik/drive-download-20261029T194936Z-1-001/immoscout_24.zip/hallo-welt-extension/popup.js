const statusEl = document.getElementById("status");

// URLs vom Content-Script holen (bei Bedarf nachladen)
async function collectUrls(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { action: "collectUrls" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return await chrome.tabs.sendMessage(tabId, { action: "collectUrls" });
  }
}

document.getElementById("startBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  try {
    const { urls } = await collectUrls(tab.id);
    if (!urls.length) {
      statusEl.textContent = "Keine Exposé-Links auf dieser Seite gefunden.";
      return;
    }
    await chrome.runtime.sendMessage({ action: "start", urls, tabId: tab.id });
    statusEl.textContent = `${urls.length} Exposés gefunden, Durchlauf gestartet.`;
  } catch (err) {
    statusEl.textContent = "Auf dieser Seite nicht möglich: " + err.message;
  }
});

document.getElementById("stopBtn").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ action: "stop" });
  statusEl.textContent = "Durchlauf gestoppt.";
});

// Beim Öffnen des Popups den aktuellen Stand anzeigen
chrome.runtime.sendMessage({ action: "status" }).then((s) => {
  if (s && s.running) {
    statusEl.textContent = `Läuft: ${s.index + 1} von ${s.queue.length}`;
  }
});
